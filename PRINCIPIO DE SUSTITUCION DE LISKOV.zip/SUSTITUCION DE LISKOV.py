# PRINCIPIO DE SUSTITUCION DE LISKOV#

class Coche():
    # Se crea la clase Coche#
    def __init__(self, marca, precio):
        self.marca = marca
        self.precio = precio

    def estado(self):
        print("marca: ", self.marca,"precio: ", self.precio)

    def numasientos(self, numeroasientos):
        print('el numero de asientos es {}'.format(numeroasientos))
# Se crea la subclase Renault, con los atributos y metodos de Coche#
class Renault(Coche):
    pass
# Se instancia micarro como Objeto de Renault, y tucarro como objeto de Coche#
micarro= Renault("twingo", "$2000")
tucarro= Coche("jaguar", "$10000")
# Cuando se convoca el metodo munsasientos funciona con la subclase Renault y con la clase Coche#
micarro.estado()
micarro.numasientos(4)
tucarro.estado()
tucarro.numasientos(5)

